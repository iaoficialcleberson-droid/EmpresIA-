import 'package:flutter/material.dart';
import 'screens/login.dart';

void main() {
  runApp(EmpresIA());
}

class EmpresIA extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'EmpresIA',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: LoginScreen(),
    );
  }
}
