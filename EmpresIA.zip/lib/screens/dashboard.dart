import 'package:flutter/material.dart';

class Dashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('EmpresIA Dashboard')),
      body: Center(
        child: Text('Bem-vindo ao EmpresIA', style: TextStyle(fontSize: 20)),
      ),
    );
  }
}
